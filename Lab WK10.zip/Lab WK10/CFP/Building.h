#pragma once
#include "CarbonFootPrint.h"
class Building :
	public CarbonFootPrint
{
private:
	int squareFeet_;

public:
	Building(int sf);
	virtual void GetCarbonFootPrint() override;
};

