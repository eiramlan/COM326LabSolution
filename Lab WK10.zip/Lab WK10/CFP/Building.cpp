#include "Building.h"

Building::Building(int sf) : squareFeet_{ sf } {

}

void Building::GetCarbonFootPrint() {
	int carbon = squareFeet_ * (50 + 20 + 47 + 17);
	std::cout << "Carbon foot print for building: " << carbon << std::endl;
}
