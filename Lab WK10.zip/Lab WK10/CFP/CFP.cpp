// CFP.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include "Bicycle.h"
#include "Building.h"
#include "Car.h"

using namespace std;

int main()
{
	vector<CarbonFootPrint*> cfpPtr;
	cfpPtr.push_back(new Bicycle());
	cfpPtr.push_back(new Building(10000));
	cfpPtr.push_back(new Car(50));

	for (int index = 0; index < cfpPtr.size(); index++) {
		cfpPtr.at(index)->GetCarbonFootPrint();
	}

	for (int index = 0; index < cfpPtr.size(); index++) {
		delete cfpPtr.at(index);
	}

	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
