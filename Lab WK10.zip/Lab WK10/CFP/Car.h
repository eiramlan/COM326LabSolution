#pragma once
#include "CarbonFootPrint.h"
class Car :
	public CarbonFootPrint
{
private:
	double gallon_;

public:
	Car(double g);
	virtual void GetCarbonFootPrint() override;
};

