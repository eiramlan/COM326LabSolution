#include "CarbonFootPrint.h"

void CarbonFootPrint::GetCarbonFootPrint() {}
