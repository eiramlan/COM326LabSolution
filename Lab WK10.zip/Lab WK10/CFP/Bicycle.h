#pragma once
#include "CarbonFootPrint.h"

class Bicycle :
	public CarbonFootPrint
{
private:
	std::string type_;

public:
	virtual void GetCarbonFootPrint() override;
};

