#include "Bicycle.h"

void Bicycle::GetCarbonFootPrint() {
	std::cout << "Carbon foot print for bicycle: 0\n";
}
