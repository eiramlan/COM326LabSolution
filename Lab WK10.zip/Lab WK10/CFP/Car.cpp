#include "Car.h"

Car::Car(double g) : gallon_{ g } {

}

void Car::GetCarbonFootPrint() {
	double carbon = gallon_ * 20;
	std::cout << "Carbon foot print for car: " << carbon << std::endl;
}