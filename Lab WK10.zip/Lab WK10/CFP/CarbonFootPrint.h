#pragma once
#include <iostream>

class CarbonFootPrint
{
public:
	virtual void GetCarbonFootPrint();
};

