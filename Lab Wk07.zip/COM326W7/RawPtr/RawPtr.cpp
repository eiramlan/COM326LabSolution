// RawPtr.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cassert>
#include <string>

using namespace std;

int HowMany();	// Task 1
int* CreateInts(int num);	// Task 2
void ReadInts(int* arrayInt, int arrIdx);	// Task 3
void DisplayInts(int* arrayInt, int arrIdx); // Task 4
void FindMaxInts(int* arrayInt, int arrIdx); // Task 5

int main()
{

	unique_ptr<int> uniquePtr1 = make_unique<int>(32);
	cout << "The value stored in the memory location: " << *uniquePtr1 << endl;
	cout << "The address of the unique pointer: " << &uniquePtr1 << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*uniquePtr1 << endl;

	cout << endl;

	unique_ptr<int> uniquePtr2 = move(uniquePtr1);
	cout << "The value stored in the memory location: " << *uniquePtr2 << endl;
	cout << "The address of the unique pointer: " << &uniquePtr2 << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*uniquePtr2 << endl;

	cout << endl;
	cout << "---------------------------------------------------------\n";

	assert(!uniquePtr1 && "Crap the pointer is still valid");
	//cout << "The value stored in the memory location: " << *uniquePtr1 << endl;
	cout << "The address of the unique pointer: " << &uniquePtr1 << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*uniquePtr1 << endl;

	cout << endl;
	shared_ptr<string> sharedPointerA = make_shared<string>();
	cout << "Please enter a string: ";
	getline(cin, *sharedPointerA);
	cout << endl;

	cout << "The address of the unique pointer: " << &sharedPointerA << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*sharedPointerA << endl;
	cout << "The value stored in the memory location: " << *sharedPointerA << endl;
	cout << "The reference count of the pointer: " << sharedPointerA.use_count() << endl;

	cout << endl;
	auto sharedPointerB(sharedPointerA);
	cout << "The address of the unique pointer: " << &sharedPointerB << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*sharedPointerB << endl;
	cout << "The value stored in the memory location: " << *sharedPointerB << endl;
	cout << "The reference count of the pointer: " << sharedPointerB.use_count() << endl;

	cout << endl;
	auto sharedPointerC(sharedPointerA);
	cout << "The address of the unique pointer: " << &sharedPointerC << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*sharedPointerC << endl;
	cout << "The value stored in the memory location: " << *sharedPointerC << endl;
	cout << "The reference count of the pointer: " << sharedPointerC.use_count() << endl;

	sharedPointerA = nullptr;

	cout << "\n-----------------------------------------------------------\n";
	cout << "The address of the unique pointer: " << &sharedPointerB << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*sharedPointerB << endl;
	cout << "The value stored in the memory location: " << *sharedPointerB << endl;
	cout << "The reference count of the pointer: " << sharedPointerB.use_count() << endl;
	cout << endl;
	cout << "The address of the unique pointer: " << &sharedPointerC << endl;
	cout << "The address of the memory location (&*) the unique pointer 1 points to is : " << &*sharedPointerC << endl;
	cout << "The value stored in the memory location: " << *sharedPointerC << endl;
	cout << "The reference count of the pointer: " << sharedPointerC.use_count() << endl;

	/*
	int howMany{ HowMany() };
	int* arrayInt{ CreateInts(howMany) };
	ReadInts(arrayInt, howMany);
	DisplayInts(arrayInt, howMany);
	FindMaxInts(arrayInt, howMany);

	// Handler for pointer cleanup
	delete[] arrayInt;
	arrayInt = nullptr;
	*/


}

int HowMany() {
	int varInt{ 0 };
	cout << "Enter no of integers: ";
	cin >> varInt;
	return varInt;
}

int* CreateInts(int num) {
	int* arrIntPtr{ new int[num] };
	return arrIntPtr;
}

void ReadInts(int* arrayInt, int arrIdx) {
	for (int i{ 0 }; i < arrIdx; i++) {
		cout << "Please enter integer value: ";
		cin >> *(arrayInt + i);
	}
}

void DisplayInts(int* arrayInt, int arrIdx) {
	cout << "Your integer values: ";
	for (int i{ 0 }; i < arrIdx; i++) {
		cout << *(arrayInt + i) << " ";
	}
}

void FindMaxInts(int* arrayInt, int arrIdx) {
	int tempMax{ *(arrayInt + 0) };
	for (int i{ 1 }; i < arrIdx; i++) {
		if (tempMax < *(arrayInt + i)) {
			tempMax = *(arrayInt + i);
		}
	}
	cout << "\nHighest integer value is: " << tempMax << endl;
}



// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
