/*
* Main.cpp
*
* Version information
* Author: Dr. Shane Wilson && Dr. Effirul Ramlan
* Date:30/09/2017 || 29/09/2019
* Description: Memory management
*
* Copyright notice
*/

#pragma once 

#include <iostream>
#include <string>
#include <vector>
#include <memory>

using namespace std;

int* GetPointer();
unique_ptr<int> GetUniquePointer();

int main(int argc, const char * argv[]) {

	int* intPtr = GetPointer();
	cout << *intPtr << endl;

	unique_ptr<int> uniPtr = move(GetUniquePointer());
	cout << *uniPtr << endl;

	delete intPtr;
	intPtr = nullptr;

	return 0;
}

// Ver.1: Conventional pointer declaration
int* GetPointer() {
	int* localPtr{ new int{5} };
	return localPtr;

}

// Ver.2: Used unique_ptr
unique_ptr<int> GetUniquePointer() {
	unique_ptr<int> uniqLPtr = make_unique<int>(5);
	return uniqLPtr;
}

/*
int* GetPointer() {
	int x{ 5 };
	return &x;

	// Explanation on why this will caused an error:
	// X will go out of scope when the function exits
	// We need to allocate memory for int* properly (to ensure that memory is retain)
}
*/