// Vect.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>

using namespace std;

void PopulateVector(vector <int>& v, int size);	// Task 1
void PrintVector(vector <int>& v, int size); // Utility function to print out vector content

int main()
{
	srand(time(0));

    // Task 2 - Print out before 7 after
	vector <int> v1{};
	vector <int> v2{};
	cout << "Original State \n";
	cout << "-------------------------------------\n";
	cout << "Size" << "\t" << "Capacity" << endl;
	cout << v1.size() << "\t" << v1.capacity() << endl;
	cout << v2.size() << "\t" << v2.capacity() << endl;

	PopulateVector(v1, 100);
	PopulateVector(v2, 100);
	cout << "\nAfter Populate \n";
	cout << "-------------------------------------\n";
	cout << "Size" << "\t" << "Capacity" << endl;
	cout << v1.size() << "\t" << v1.capacity() << endl;
	cout << v2.size() << "\t" << v2.capacity() << endl;
	PrintVector(v1, 100);
	PrintVector(v2, 100);

	// Task 3 - Sort vector using built in sort
	sort(v1.begin(), v1.end());
	sort(v2.begin(), v2.end());
	cout << "\nAfter Sorting \n";
	cout << "-------------------------------------\n";
	cout << "Size" << "\t" << "Capacity" << endl;
	cout << v1.size() << "\t" << v1.capacity() << endl;
	cout << v2.size() << "\t" << v2.capacity() << endl;
	PrintVector(v1, 100);
	PrintVector(v2, 100);

	// Task 4 - Resizing the vector
	v1.shrink_to_fit();
	v2.shrink_to_fit();
	cout << "\nAfter Resizing \n";
	cout << "-------------------------------------\n";
	cout << "Size" << "\t" << "Capacity" << endl;
	cout << v1.size() << "\t" << v1.capacity() << endl;
	cout << v2.size() << "\t" << v2.capacity() << endl;
	
	// Task 5 - Remove duplicates
	int idx{ 100 };
	for (int i = 0; i < 100; i++) {
		for (int j = 0; j < idx; j++) {
			if (v1.at(i) == v2.at(j)) {
				v2.erase(v2.begin() + j);
				idx--;
			}
		}
	}
	cout << "\nAfter Removing duplicates \n";
	cout << "-------------------------------------\n";
	cout << "Size" << "\t" << "Capacity" << endl;
	cout << v1.size() << "\t" << v1.capacity() << endl;
	cout << v2.size() << "\t" << v2.capacity() << endl;
}

void PopulateVector(vector <int>& v, int size) {
	for (int i = 0; i < size; i++) {
		v.push_back((rand() % 1000));
	}
}

void PrintVector(vector <int>& v, int size) {
	cout << "\n{ ";
	for (int i = 0; i < size; i++) {
		cout << v.at(i) << " ";
	}
	cout << "}" << endl;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
