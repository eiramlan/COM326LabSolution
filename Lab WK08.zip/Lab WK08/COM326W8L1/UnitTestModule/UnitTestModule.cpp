#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace TestingModule
{
	TEST_CLASS(UnitTestModule)
	{
	public:

		TEST_METHOD(TestCustomConstructor)
		{
			// Arrange
			std::string mTitle{ "Basic Unit Testing for C++" };
			std::string mCode{ "COM326-W8" };
			int cHour{ 20 };

			// Act
			Module* modulePtr{ new Module{ mTitle,mCode, cHour, 0 } };

			// Assert
			Assert::IsNotNull(modulePtr);
			delete modulePtr;
			modulePtr = nullptr;
		}

		TEST_METHOD(TestGetModuleCode)
		{
			// Arrange
			std::string mTitle{ "Basic Unit Testing for C++" };
			std::string mCode{ "COM326-W8" };
			int cHour{ 20 };
			Module defModule{ mTitle, mCode, cHour, 0 };

			std::string expected{ mCode };
			std::string actual{};

			// Act
			actual = defModule.getModuleCode();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestSetModuleCode)
		{
			// Arrange
			Module defModule;
			std::string expected{ "COM326-W8" };
			std::string actual{};

			// Act
			defModule.setModuleCode("COM326-W8");
			actual = defModule.getModuleCode();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestGetModuleCreditPoint)
		{
			// Arrange
			std::string mTitle{ "Basic Unit Testing for C++" };
			std::string mCode{ "COM326-W8" };
			int cHour{ 20 };
			int cPoint{ 20 };
			Module defModule{ mTitle, mCode, cHour, cPoint };

			int expected{ cPoint };
			int actual{};

			// Act
			actual = defModule.getModuleCreditPoints();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestSetModuleCreditPoint)
		{
			// Arrange
			Module defModule;
			std::string expected{ 20 };
			std::string actual{};

			// Act
			defModule.setModuleCreditPoints(20);
			actual = defModule.getModuleCreditPoints();

			// Assert
			Assert::AreEqual(expected, actual);
		}
	};
}

namespace TestingStudent
{
	TEST_CLASS(UnitTestModule)
	{
	public:
		TEST_METHOD(TestStudentCustomConstructor)
		{
			// Arrange
			Module tempM1{ "Fundamental of Programming", "COM149", 20, 70 };
			Module tempM2{ "Object Oriented Programming", "COM326", 20, 90 };
			Module tempM3{ "Data Structures", "COM328", 20, 90 };
			std::vector<Module> m{ 3 };
			
			// Act
			m.at(0) = tempM1;
			m.at(1) = tempM2;
			m.at(2) = tempM3;
			Student* defStudent{ new Student{ "Jeni Watt", "B004568656", "BSc Computing", 3, m } };

			// Assert
			Assert::IsNotNull(defStudent);
			delete defStudent;
			defStudent = nullptr;
		}

		TEST_METHOD(TestStudentAddModule1)
		{
			// Arrange
			std::vector<Module> m{};
			m.push_back(Module{ "Fundamental of Programming", "COM149", 20, 70 });
			m.push_back(Module{"Object Oriented Programming", "COM326", 20, 90 });
			Student defStudent{ "Jeni Watt", "B004568656", "BSc Computing", 3, m };
			Module tempM3{ "Data Structures", "COM328", 20, 90 };
			int expected{ 3 };
			int actual{};

			// Act
			defStudent.AddModule(tempM3);
			actual = defStudent.GetModule();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestStudentAddModule2)
		{
			// Arrange
			std::vector<Module> m{};
			m.push_back(Module{ "Fundamental of Programming", "COM149", 20, 70 });
			
			Student defStudent{ "Jeni Watt", "B004568656", "BSc Computing", 3, m };
			int expected{ 2 };
			int actual{};

			// Act
			defStudent.AddModule("Object Oriented Programming", "COM326", 20, 90);
			actual = defStudent.GetModule();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestStudentCalculateClassification)
		{
			// Arrange
			std::vector<Module> m{};
			m.push_back(Module{ "Fundamental of Programming", "COM149", 20, 90 });
			m.push_back(Module{ "Object Oriented Programming", "COM326", 20, 90 });

			Student defStudent{ "Jeni Watt", "B004568656", "BSc Computing", 3, m };
			std::string expected{ "1st class" };
			std::string actual{};

			// Act
			actual = defStudent.CalculateClassification();

			// Assert
			Assert::AreEqual(expected, actual);
		}

		TEST_METHOD(TestStudentDeleteModule)
		{
			// Arrange
			std::vector<Module> m{};
			m.push_back(Module{ "Fundamental of Programming", "COM149", 20, 90 });
			m.push_back(Module{ "Object Oriented Programming", "COM326", 20, 90 });
			m.push_back(Module{ "Data Structures", "COM328", 20, 90 });

			Student defStudent{ "Jeni Watt", "B004568656", "BSc Computing", 3, m };
			int expected{ 2 };
			int actual{};

			// Act
			defStudent.DeleteModule("COM328");
			actual = defStudent.GetModule();

			// Assert
			Assert::AreEqual(expected, actual);
		}
	};
}
