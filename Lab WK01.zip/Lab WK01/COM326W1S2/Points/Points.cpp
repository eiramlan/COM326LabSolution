/*
* Gambler.cpp
*
* Version information
* Author: Dr. Shane Wilson
* Date:25/09/2017
* Description: Solution to week 1 points challenge
*
* Copyright notice
*/

#include <iostream>
#include <random>


int GenerateThrow();

int main(int argc, const char * argv[]) {

	int playerOneScore{ 12 }, playerTwoScore{ 12 };
	bool winner{ 0 };
	int score{ 0 }, numberThrows{ 0 };


	while (!winner) {
		score = 0;
		numberThrows++;
		score = GenerateThrow() + GenerateThrow() + GenerateThrow();
		std::cout << "\nPlayer One throws a: " << score << std::endl;
		if (score == 14) {
			playerOneScore++;
			playerTwoScore--;
		}
		numberThrows++;
		score = GenerateThrow() + GenerateThrow() + GenerateThrow();
		std::cout << "Player Two throws a: " << score << std::endl;
		if (score == 11) {
			playerOneScore--;
			playerTwoScore++;
		}
		std::cout << "Scores on the doors are: " << "\tPlayer one: " << playerOneScore << "\tPlayer two:" << playerTwoScore << std::endl;
		
		// Check to initialise variable to stop the game
		if (playerOneScore == 0 || playerTwoScore == 0) {
			winner = 1;
			std::cout << "\n\nThe total number of throws was: " << numberThrows << "\nWOW that's a lot!" << std::endl;
		}
		
	}


	return 0;
}

int GenerateThrow() {
	
	std::random_device rd; 
	std::mt19937 gen(rd()); 
	std::uniform_int_distribution<> dis(1, 6);
	
	return dis(gen);
}

