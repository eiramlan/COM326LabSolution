#include "Brawler.h"

Brawler::Brawler() {
	punchDamage_ = 10;
	strength_ = 5;
}

Brawler::Brawler(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int punchDamage, int strength) :
	GameCharacter(name, health, weightLimit, weapon, armour, food, state), punchDamage_{ punchDamage }, strength_{ strength } {
}

void Brawler::SetPunchDamage(int damage) {
	punchDamage_ = damage;
}

int Brawler::GetPunchDamage() const {
	return punchDamage_;
}

void Brawler::SetStrength(int strength) {
	strength_ = strength;
}

int Brawler::GetStrength() const {
	return strength_;
}

bool Brawler::Attack(GameCharacter& character) {
	if (character.GetCharacterState() != CharacterState::Dead) {
		std::cout << "Brawler ";
		return GameCharacter::Attack(character);
	}
	return false;
}

bool Brawler::Brawl(GameCharacter& character) {
	std::cout << "Brawler " << GameCharacter::GetCharacterName() << " is brawling " << character.GetCharacterName();
	return true;
}

void Brawler::Sleep() {
	float current = GameCharacter::GetCharacterHealth();
	GameCharacter::SetCharacterHealth(current + (current * 0.15));
	GameCharacter::Sleep();
}
