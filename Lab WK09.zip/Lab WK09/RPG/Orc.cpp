#include "Orc.h"

Orc::Orc() {
	ferociousness_ = 0;
	strength_ = 0;
}

Orc::Orc(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int ferocious, int strength) :
	GameCharacter(name, health, weightLimit, weapon, armour, food, state), ferociousness_{ ferocious }, strength_{ strength } {

}

void Orc::SetFerociousness(int ferocious) {
	ferociousness_ = ferocious;
}

int Orc::GetFerociousness() const {
	return ferociousness_;
}

void Orc::SetStrength(int strength) {
	strength_ = strength;
}

int Orc::GetStrength() const {
	return strength_;
}

bool Orc::Attack(GameCharacter& character) {
	if (character.GetCharacterState() != CharacterState::Dead) {
		std::cout << "Orc ";
		return GameCharacter::Attack(character);
	} 
	return false;
}

void Orc::Scream(GameCharacter& character) {
	std::cout << "Orc " << GameCharacter::GetCharacterName() << " is screaming at " << character.GetCharacterName();
}

void Orc::Sleep() {
	float current = GameCharacter::GetCharacterHealth();
	GameCharacter::SetCharacterHealth(current + (current * 0.15));
	GameCharacter::Sleep();
}
