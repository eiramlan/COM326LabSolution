#include "BlackWitch.h"

BlackWitch::BlackWitch() {
	magicProficiency_ = 0;
	darkPower_ = 0;
}

BlackWitch::BlackWitch(std::string name, float health, float weightLimit, Weapon weapon, Armour armour, int food, CharacterState state, int magic, int power) :
	GameCharacter(name, health, weightLimit, weapon, armour, food, state), magicProficiency_{ magic }, darkPower_{ power } {
}

void BlackWitch::SetMagicProficiency(int magic) {
	magicProficiency_ = magic;
}

int BlackWitch::GetMagicProficiency() const {
	return magicProficiency_;
}

void BlackWitch::SetDarkPower(int power) {
	darkPower_ = power;
}

int BlackWitch::GetDarkPower() const {
	return darkPower_;
}

bool BlackWitch::Attack(GameCharacter& character) {
	if (character.GetCharacterState() != CharacterState::Dead) {
		std::cout << "Black witch ";
		return GameCharacter::Attack(character);
	}
	return false;
}

void BlackWitch::Bewitch(GameCharacter& character) {
	std::cout << "Black witch " + GameCharacter::GetCharacterName() << " is attempting to bewitch " << character.GetCharacterName() << std::endl;
}

void BlackWitch::Sleep() {
	float current = GameCharacter::GetCharacterHealth();
	GameCharacter::SetCharacterHealth(current + (current * 0.15));
	GameCharacter::Sleep();
}
