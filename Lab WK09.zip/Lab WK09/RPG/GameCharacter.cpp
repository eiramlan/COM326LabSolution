#include "GameCharacter.h"

GameCharacter::GameCharacter() {
	characterName_ = "Default character";
	health_ = 100;
	weightLimit_ = 80.0f;
	food_ = 100;
	state_ = CharacterState::Idle;
	
	Weapon defWeapon("Stick", 5, 1.0f, 5, 100);
	weapon_ = defWeapon;

	Armour defArmour("Inner", 5, 1.0f, 5, 100, ArmourType::Cardboard);
	armour_ = defArmour;
	std::cout << "A Game Character called " << characterName_ << " has been born\n";
}

GameCharacter::GameCharacter(std::string name, float health, float weight, Weapon weapon, Armour armour, int food, CharacterState state) : 
	characterName_{ name }, health_{ health }, weightLimit_{ weight }, weapon_{ weapon }, armour_{ armour }, food_{ food }, state_{ state } {
	std::cout << "A Game Character called " << characterName_ << " has been born\n";
}

void GameCharacter::SetCharacterName(std::string name) {
	characterName_ = name;
}

std::string GameCharacter::GetCharacterName() const {
	return characterName_;
}

void GameCharacter::SetCharacterHealth(float health) {
	health_ = health;
}

float GameCharacter::GetCharacterHealth() const {
	return health_;
}

void GameCharacter::SetCharacterWeightLimit(float weightLimit) {
	weightLimit_ = weightLimit;
}

float GameCharacter::GetCharacterWeightLimit() const {
	return weightLimit_;
}

void GameCharacter::SetCharacterWeapon(Weapon weapon) {
	weapon_ = weapon;
}

Weapon GameCharacter::GetCharacterWeapon() const {
	return weapon_;
}

void GameCharacter::SetCharacterArmour(Armour armour) {
	armour_ = armour;
}

Armour GameCharacter::GetCharacterArmour() const {
	return armour_;
}

void GameCharacter::SetCharacterFood(int food) {
	food_ = food;
}

int GameCharacter::GetCharacterFood() const {
	return food_;
}

void GameCharacter::SetCharacterState(CharacterState state) {
	state_ = state;
}

CharacterState GameCharacter::GetCharacterState() const {
	return state_;
}

void GameCharacter::AddFood(int amount) {
	food_ += amount;
}

void GameCharacter::Eat() {
	if (food_ >= 4) {
		health_ += 1;
		food_ -= 4;
	}
	else if (food_ > 0) {
		health_ += (food_ * 0.25);
		food_ -= food_;
	}
}

bool GameCharacter::Attack(GameCharacter& character) {
	std::cout << characterName_ << " is attacking " << character.GetCharacterName() << " with a " << weapon_.GetItemName() << std::endl;
	state_ = CharacterState::Attacking;

	if (weapon_.GetItemName() == "") {
		return false; // Character cannot attack because there is no weapon
	}
	else if (health_ <= 20) {
		return false; // Character cannot attack because health is less than 20
	}
	else if (character.GetCharacterHealth() <= 0) {
		return false; // Character is dead
	}

	int chances{ 0 };
	if (character.armour_.GetItemName() == "") {
		chances = 80;
	}
	else if (weapon_.GetWeaponHitStrength() > character.armour_.GetArmourDefence()) {
		chances = 60;
	}
	else {
		chances = 20;
	}

	float charHealth{ character.GetCharacterHealth() };
	int armourHealth{ character.armour_.GetArmourHealth() };

	if (rand() % 100 < chances) {
		switch (character.GetCharacterState()) {
		case CharacterState::Defending: charHealth = charHealth - (charHealth * 0.10);
			break;
		case CharacterState::Sleeping: charHealth = 0;
			break;
		default: charHealth = charHealth - (charHealth * 0.30);
			break;
		}
		character.SetCharacterHealth(charHealth);
		armourHealth = armourHealth - (armourHealth * 0.50);
		character.armour_.SetArmourHealth(armourHealth);
		if (armour_.GetArmourHealth() <= 0) {
			armour_.SetItemName("");
		}
	}

	int damage{ weapon_.GetWeaponHealth() };
	if (character.armour_.GetItemName() != "") {
		chances = (rand() % 1);
		if (chances == 0) {
			damage = damage - (damage * 0.1);
		}
		else {
			damage = damage - (damage * 0.2);
		}
	}

	weapon_.SetWeaponHealth(damage);

	if (weapon_.GetWeaponHealth() <= 0) {
		weapon_.SetItemName("");
	}
	
	return true;
}

void GameCharacter::Defend() {
	std::string strTmp{};
	switch (armour_.GetArmourType()) {
	case ArmourType::Cardboard: strTmp = "Cardboard"; break;
	case ArmourType::Iron: strTmp = "Iron"; break;
	case ArmourType::Leather: strTmp = "Leather"; break;
	case ArmourType::Steel: strTmp = "Steel"; break;
	case ArmourType::Wood: strTmp = "Wood"; break;
	}
	std::cout << characterName_ << " is defending themselves with a " << armour_.GetItemName() << " made from " << strTmp;
	state_ = CharacterState::Defending;
}

void GameCharacter::Walk() {
	std::cout << characterName_ << " is walking\n";
	state_ = CharacterState::Walking;
}

void GameCharacter::Run() {
	std::cout << characterName_ << " is running\n";
	state_ = CharacterState::Running;
}

void GameCharacter::Sleep() {
	std::cout << characterName_ << " is sleeping\n";
	state_ = CharacterState::Sleeping;
}

