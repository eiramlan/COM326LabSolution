/*
* RPG.cpp : This file contains the 'main' function. Program execution begins and ends there.
*
* Version information v0.1
* Author: Dr. Shane Wilson && Dr. Effirul Ramlan
* Date: 12/10/2017 || 10/11/2019
* Description: Driver to test the RPG classes - included in the additional challenges
* Copyright notice
*/

#include <iostream>
#include <cstdlib>
#include <ctime>

#include "Weapon.h"
#include "Armour.h"
#include "BlackWitch.h"
#include "Brawler.h"
#include "Orc.h"
#include "Cleric.h"

using namespace std;

void PrintLogo();
void PrintCharacterStatus(GameCharacter& c);
bool CheckStatus(GameCharacter& c);
int RollDiceMove(int range);

int main()
{
	srand(time(0));
	int playerCtr{ 4 };	// to count how many player alive every turn
	int counter{ 1 };
	char flag{ 'Y' };

	// A simulation to test the effectiveness of the construction of inherited classes
	// Character initialisation
	PrintLogo();
	cout << "Character Initialisation: \n";
	cout << "-----------------------------------------------------------------\n";
	Brawler zangief("Zangief", 100.0f, 120.0f, Weapon{"Bare Hands", 50, 5.5f, 50, 100}, Armour{}, 100, CharacterState::Idle, 55, 50);
	Orc azog("Azog", 100.0, 225.5f, Weapon{ "Orc Scimitar", 25, 7.5f, 35, 100 }, Armour{ "Full Body", 25, 5.5f, 50, 100, ArmourType::Steel }, 35, CharacterState::Idle, 80, 50);
	BlackWitch bellatrix("Bellatrix Lestrange", 100.0f, 50.5f, Weapon{ "Wand", 50, 0.25f,75, 100 }, Armour{}, 75, CharacterState::Idle, 100, 100);
	Cleric samwell("Samwell Tarly", 100.0f, 150.0f, Weapon{ "Sword", 100, 5.0f, 75, 100 }, Armour{ "Full Body", 50, 5.5f, 80, 100, ArmourType::Steel }, 50, CharacterState::Idle, 5);

	cout << "\n--------------------------------------------------------------\n";
	// This is a battle royal, to which only 1 will survive
	while (playerCtr > 1) {
		playerCtr = 4;	// reset everytime

		// Roll a dice to see who will move, what move, and damage if necessary
		// We should pause in between - for effect
		cout << "\nStarting Round " << counter << endl;

		char choice{};
		switch (RollDiceMove(4)) {
		case 1:
			if (zangief.GetCharacterState() != CharacterState::Dead) {
				cout << zangief.GetCharacterName() << " Move - [A]ttack, [B]rawl, [S]leep : ";
				cin >> choice;
				if (choice == 'A') {
					zangief.Attack(azog);
					zangief.Attack(bellatrix);
					zangief.Attack(samwell);
				}
				else if (choice == 'B') {
					zangief.Brawl(azog);
					zangief.Attack(bellatrix);
					zangief.Attack(samwell);
				}
				else if (choice == 'S') {
					zangief.Sleep();
				}
			}
			else {
				flag = 'N';
			}
			break;
		case 2:
			if (azog.GetCharacterState() != CharacterState::Dead) {
				cout << azog.GetCharacterName() << " Move - [A]ttack, [Sc]ream, [S]leep : ";
				cin >> choice;
				if (choice == 'A') {
					azog.Attack(zangief);
					azog.Attack(bellatrix);
					azog.Attack(samwell);
				}
				else if (choice == 'Sc') {
					azog.Scream(zangief);
					azog.Scream(bellatrix);
					azog.Scream(samwell);
				}
				else if (choice == 'S') {
					azog.Sleep();
				}
			}
			else {
				flag = 'N';
			}
			break;
		case 3:
			if (bellatrix.GetCharacterState() != CharacterState::Dead) {
				cout << bellatrix.GetCharacterName() << " Move - [A]ttack, [B]ewitch, [S]leep : ";
				cin >> choice;
				if (choice == 'A') {
					bellatrix.Attack(zangief);
					bellatrix.Attack(azog);
					bellatrix.Attack(samwell);
				}
				else if (choice == 'B') {
					bellatrix.Bewitch(zangief);
					bellatrix.Bewitch(azog);
					bellatrix.Bewitch(samwell);
				}
				else if (choice == 'S') {
					bellatrix.Sleep();
				}
			}
			else {
				flag = 'N';
			}
			break;
		case 4:
			if (samwell.GetCharacterState() != CharacterState::Dead) {
				cout << samwell.GetCharacterName() << " Move - [A]ttack, [P]ray for, [S]leep : ";
				cin >> choice;
				if (choice == 'A') {
					samwell.Attack(zangief);
					samwell.Attack(azog);
					samwell.Attack(bellatrix);
				}
				else if (choice == 'P') {
					samwell.PrayFor(zangief);
					samwell.PrayFor(azog);
					samwell.PrayFor(bellatrix);
				}
				else if (choice == 'S') {
					bellatrix.Sleep();
				}
			}
			else {
				flag = 'N';
			}
			break;
		}

		cout << "\n*************************************************\n";
		PrintCharacterStatus(zangief);
		PrintCharacterStatus(azog);
		PrintCharacterStatus(bellatrix);
		PrintCharacterStatus(samwell);
		cout << "*************************************************\n";

		if (flag == 'Y') {
			if (CheckStatus(zangief)) { playerCtr--; };
			if (CheckStatus(azog)) { playerCtr--; };
			if (CheckStatus(bellatrix)) { playerCtr--; };
			if (CheckStatus(samwell)) { playerCtr--; };
		}
		else {
			flag = 'Y';
		}
		counter++;
	}

	cout << "\n*************************************************\n";
	cout << "FINAL RESULTS: " << endl;
	cout << "\n*************************************************\n";
	PrintCharacterStatus(zangief);
	PrintCharacterStatus(azog);
	PrintCharacterStatus(bellatrix);
	PrintCharacterStatus(samwell);
	cout << "*************************************************\n";

	cout << "GAME OVER" << endl;

	return 0;
}

void PrintLogo() {
	cout << " _______________________________\n";
	cout << "|     ______ ______  _____      |\n";
	cout << "|     | ___ \\| ___ \\|  __ \\     |\n";
	cout << "|     | |_/ /| |_/ /| |  \\/     |\n";
	cout << "|     |    / |  __/ | | __      |\n";
	cout << "|     | |\\ \\ | |    | |_\\ \\     |\n";
	cout << "|     \\_| \\_|\\_|    \\_____/     |\n";
	cout << "|_______________________________|\n";
	cout << endl;
}

bool CheckStatus(GameCharacter& c) {
	if (c.GetCharacterHealth() < 1) {
		c.SetCharacterState(CharacterState::Dead);
		return true;
	}
	return false;
}

void PrintCharacterStatus(GameCharacter& c) {
	if (c.GetCharacterState() == CharacterState::Dead) {
		cout << "[DEAD]";
	}
	else {
		cout << "[" << c.GetCharacterHealth() << "%]";
	}
	cout << " -- Health " << " " << c.GetCharacterName() << endl;
}

int RollDiceMove(int range) {
	return 1 + (rand() % range);
}

