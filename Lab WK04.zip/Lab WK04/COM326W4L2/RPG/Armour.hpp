#pragma once
#include <string>

// Task 1 for Challenge 2 - adding armour enum type
enum class ArmourType { Helmet, shield, gloves, chest, leg, arms };
enum class ArmourMaterial { Steel, Iron, Leather, Wood, Cloth, Paper };

class Armour {

private:
	std::string name_;
	std::string description_;
	int value_;
	int weight_;
	ArmourType armourType_;
	ArmourMaterial armourMaterial_;
	int defensiveValue_;
	bool equipped_;

public:
	Armour() {
		value_ = GetValue();
		weight_ = GetWeight();
		armourType_ = GetArmourType();
		armourMaterial_ = GetArmourMaterial();
		defensiveValue_ = GetDefensiveValue();
		equipped_ = GetEquipped();
	}

	std::string GetName() const {
		return name_;
	}

	void SetName(std::string name) {
		name_ = name;
	}

	std::string GetDescription() const {
		return description_;
	}

	void SetDescription(std::string description) {
		description_ = description;
	}

	int GetValue() const {
		return value_;
	}

	void SetValue(int value) {
		value_ = value;
	}

	int GetWeight() const {
		return weight_;
	}

	void SetWeight(int weight) {
		weight_ = weight;
	}

	void SetDefensiveValue(int value) {
		defensiveValue_ = value;
	}

	int GetDefensiveValue() const {
		return defensiveValue_;
	}

	void SetArmourType(ArmourType at) {
		armourType_ = at;
	}

	ArmourType GetArmourType() const {
		return armourType_;
	}

	void SetArmourMaterial(ArmourMaterial am) {
		armourMaterial_ = am;
	}

	ArmourMaterial GetArmourMaterial() const {
		return armourMaterial_;
	}

	void SetEquipped(bool equip) {
		equipped_ = equip;
	}

	bool GetEquipped() const {
		return equipped_;
	}

	void printArmour() {
		// function to allow cout<< stream for armourType and armourMaterial
		if (GetEquipped()) {
			std::string strOutput = "\n";
			switch (armourType_) {
			case ArmourType::Helmet: strOutput += "Helmet \t";
				break;
			case ArmourType::chest: strOutput += "Chest \t";
				break;
			case ArmourType::gloves: strOutput += "Gloves \t";
				break;
			case ArmourType::leg: strOutput += "Leg \t";
				break;
			case ArmourType::arms: strOutput += "Arms \t";
				break;
			}

			switch (armourMaterial_) {
			case ArmourMaterial::Steel: strOutput += "Steel \t";
				break;
			case ArmourMaterial::Iron: strOutput += "Iron \t";
				break;
			case ArmourMaterial::Leather: strOutput += "Leather \t";
				break;
			case ArmourMaterial::Wood: strOutput += "Wood \t";
				break;
			case ArmourMaterial::Cloth: strOutput += "Cloth \t";
				break;
			case ArmourMaterial::Paper: strOutput += "Paper \t";
				break;
			}
			std::cout << strOutput << GetDefensiveValue() << std::endl;
		}
		else {
			std::cout << "NO Armour necessary !!!" << std::endl;
		}
	}
};