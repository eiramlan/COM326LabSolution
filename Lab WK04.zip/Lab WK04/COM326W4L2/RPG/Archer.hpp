#pragma once
#include <iostream>
#include <vector>
#include "Weapon.hpp"
#include "Item.hpp"
#include "Armour.hpp"

class Archer {
private:
	std::string charName_;
	std::string charType_;
	int health_;
	int level_;
	Weapon weapon_;
	std::vector<Item> inventory_{};		// Task 2: create an object for item called inventory_
	std::vector<Armour> armour_{};		// Task 2: Challenge 2 - create objct for armour_

public:
	Archer() {
		std::cout << "An Archer was just born via the default constructor !!!\n\n";
		weapon_.SetWeaponType("Bow");
		weapon_.SetWeaponDamage(15.0);
		weapon_.SetWeaponLevel(1);
		SetCharHealth(100);
		SetCharLevel(1);
	}

	Archer(std::string cName, std::string cType, int cHealth, int cLevel, Weapon cWeapon, std::vector<Item> i)
		: charName_{ cName }, charType_{ cType }, health_{ cHealth }, level_{ cLevel }, weapon_{ cWeapon }, inventory_{ i } {
		std::cout << "An Archer was just born !!!\n\n";
		weapon_.SetWeaponType("Bow");
		weapon_.SetWeaponDamage(15.0);
		weapon_.SetWeaponLevel(1);
	}

	~Archer() {}

	void SetCharName(std::string cName) {
		charName_ = cName;
	}

	std::string GetCharName() const {
		return charName_;
	}

	void SetCharType(std::string cType) {
		charType_ = cType;
	}

	std::string GetCharType() const {
		return charType_;
	}

	void SetCharHealth(int cHealth) {
		health_ = cHealth;
	}

	int GetCharHealth() const {
		return health_;
	}

	void SetCharLevel(int cLevel) {
		level_ = cLevel;
	}

	int GetCharLevel() const {
		return level_;
	}

	float GetDamageImpact() const {
		float varD = weapon_.GetWeaponDamage() * weapon_.GetWeaponLevel();
		return varD;
	}

	void PrintStatus() {
		std::cout << "\n--- Archer details ---\n";
		std::cout << "Name: " << GetCharName() << std::endl;
		std::cout << "Character Type: " << GetCharType() << std::endl;
		std::cout << "Health Level: " << GetCharHealth() << std::endl;
		std::cout << "Character Level: " << GetCharLevel() << std::endl;
		std::cout << "Weapon Specs: " << weapon_.GetWeaponType() << " Damage: " 
			<< weapon_.GetWeaponDamage() << " Level: " << weapon_.GetWeaponLevel() << std::endl;
		
		if (GetCharHealth() <= 0) {
			std::cout << "Argghh, I've been killed !!\n";
		}
	}

	// Task 3 - Add and Remove from inventory
	void PickUpItem(Item item) {
		inventory_.push_back(item);
	}

	void DropItem(Item item) {
		//Search for a matching item in the inventory
		std::vector<Item>::iterator it;

		for (it = inventory_.begin(); it != inventory_.end(); it++)
			std::cout << it._Ptr->GetName() << ' ';

		for (int index = 0; index != inventory_.size(); index++) {
			if (inventory_[index].GetName() == item.GetName()) {
				inventory_.erase(inventory_.begin() + index);
			}
		}
	}

	// Task 4 - Print Inventory & added Task 4 for Challenge 2
	void ListInventory() {
		std::cout << "\nThe inventory for character " << GetCharName() << " is:" << std::endl;

		//Display all object items for the character
		std::vector<Item>::iterator it;
		for (it = inventory_.begin(); it != inventory_.end(); it++) {
			std::cout << "\n" << it._Ptr->GetName() << "\t" << it._Ptr->GetDescription() << "\t" << it._Ptr->GetValue() << std::endl;
		}

		//Display all object armour objects for the character
		std::vector<Armour>::iterator am;
		for (am = armour_.begin(); am != armour_.end(); am++) {
			am._Ptr->printArmour();
		}

		// Conventional Loop - without iterator
		/*
		std::cout << "\nThe inventory for character " << GetCharName() << " is:" << std::endl;
		for (int index = 0; index != inventory_.size(); index++) {
			std::cout << "\n" << inventory_.at(index).GetName() << "\t" << inventory_.at(index).SetDescription() << "\t" << inventory_.at(index).GetValue() << std::endl;
		}
		*/
	}

	// Task 2 - Challenge 2 = utility fuctions for armour
	void PickUpArmour(Armour arm) {
		armour_.push_back(arm);
	}

	void DropArmour(Armour arm) {
		//Search for a matching item in the inventory
		std::vector<Armour>::iterator it;

		for (it = armour_.begin(); it != armour_.end(); it++)
			std::cout << it._Ptr->GetName() << ' ';

		for (int index = 0; index != armour_.size(); index++) {
			if (armour_[index].GetName() == arm.GetName()) {
				armour_.erase(armour_.begin() + index);
			}
		}
	}
};
