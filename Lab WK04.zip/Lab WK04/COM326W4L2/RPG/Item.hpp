#pragma once
#include <string>

// Task 1: Create an Item class

class Item
{
private:
	std::string name_;
	std::string description_;
	int value_;

public:
	Item() {
		value_ = GetValue();
	}

	Item(std::string name, std::string description, int value)
		: name_{ name }, description_{ description }, value_{ value } {
	}

	std::string GetName() const {
		return name_;
	}

	void SetName(std::string name) {
		name_ = name;
	}

	std::string GetDescription() const {
		return description_;
	}

	void SetDescription(std::string description) {
		description_ = description;
	}

	int GetValue() const {
		return value_;
	}

	void SetValue(int value) {
		value_ = value;
	}
};

